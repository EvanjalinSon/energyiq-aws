import json
import boto3

def lambda_handler(event, context):
    print("FullEvent:", event)
    body= json.loads(event["body"])

    required_fields = ["meter_id", "timestamp", "energy_kwh"]
    for field in required_fields:
        if field not in body:
            return {
                "statusCode": 400,
                "body": f"Missing required field: {field}"
            }

    ssm = boto3.client('ssm')
    parameter = ssm.get_parameter(Name='/energyiq/sqs/reading-queue-url')
    queue_url = parameter["Parameter"]["Value"]

    sqs = boto3.client('sqs')
    response=sqs.send_message(
        QueueUrl= queue_url,
        MessageBody=json.dumps(body)
    )
    print(response)

    return {
    "statusCode": 200,
    "body": "Message sent"
    }
