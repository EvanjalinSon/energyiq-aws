import json
import boto3
from decimal import Decimal
secret = boto3.client("secretsmanager")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("EnergyReadings")

s3= boto3.client('s3')
def lambda_handler(event, context):
    

    print("Number of records received:", len(event["Records"]))

    for record in event["Records"]:

        body = json.loads(record["body"])

        print("Processing:", body)

        table.put_item(
            Item={
                "meter_id": body["meter_id"],
                "timestamp": body["timestamp"],
                "energy_kwh": Decimal(str(body["energy_kwh"]))
            }
        )

        
        response = s3.put_object(Bucket='energyiq-data-key-bucket', Key = f"energy-readings/{body['meter_id']}/{body['timestamp']}.json", Body=json.dumps(body))
        print(response)

        val= secret.get_secret_value(SecretId="energyiq/demo/api") 
        value = json.loads(val['SecretString'])
        print(type(value))
        print(value.keys())
        key = value['api_key']
        print(key)

    return {
        "statusCode": 200
    }